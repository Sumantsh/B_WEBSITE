@extends('layout') 

@section('content')
    <div class="alert alert-danger">
        {{ $errorMessage }}
    </div>
@endsection