@extends('layout.main')
@section('title', 'About us')

@section('content')

<div class="about_wrapper">
    <h2>About us</h2>
</div>

@endsection




