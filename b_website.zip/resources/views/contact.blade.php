@extends('layout.main')
@section('title', 'Contact us')

@section('content')

<div class="about_wrapper">
    <h2>Contact</h2>
</div>

@endsection




