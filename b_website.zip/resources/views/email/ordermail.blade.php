<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
</head>
<body>

    <h1>{{$maildata['title']}}</h1>
    <p>{{$maildata['body']}}</p>

    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quaerat quo adipisci totam amet in iste. In magnam, consequatur suscipit reprehenderit quisquam rem dolore, alias aliquid, voluptatum nesciunt numquam dolor unde?</p>

    <p>Thank You</p>
    
</body>
</html>