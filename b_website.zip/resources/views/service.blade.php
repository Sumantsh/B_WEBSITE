@extends('layout.main')
@section('title', 'Service')

@section('content')

<div class="about_wrapper">
    <h2>Service Page</h2>
</div>

@endsection




