
<?php $__env->startSection('title', 'Product Page'); ?>

<?php $__env->startSection('product_details'); ?>




<div class="text">

  <p class="page_detail"><span> Home <i class="fa-solid fa-chevron-right"></i></span><span> <?php echo e($product->company); ?> <i class="fa-solid fa-chevron-right"> </i></span> <span> <?php echo e($product->prd_cate); ?>  <i class="fa-solid fa-chevron-right"> </i></span></p>

  <div class="product_wrapper">
    
    <div class="product_detail_wrapper">

        <div class="prd_detail_image">
            <img class="prd_image2" src="<?php echo e(asset ($product->prd_img)); ?>" alt="">
        

        </div>

        <div class="prd_detail">

            <div class="prd_detail_title">
                <h2 class="prd_title2"><?php echo e($product->prd_title); ?></h2>
            </div>

            
           

            <div class="highlight">
                <p class="highlight_para" style="font-weight: 600;color:black">Highlights:</p>
                <p class="highlight_show"><?php echo e($product->highlight); ?>.</p>
            </div>




            <div class="prd_detail_price_design">

                <div class="prd_price_absolute">
                    <p class="prd_price2">Price: $<span><?php echo e($product->prd_price); ?></span></p>
            </div>



                <div class="prd_detail_price">
                    <a class="buy_now" href="<?php echo e(URL ('Checkout')); ?>/<?php echo e($product['prd_id']); ?>">Buy Now</a>                
                </div>
            </div>

           

        </div>
    </div>
  </div>

</div>

<div class="discription">
    <div class="store">
        <h2 >Product Discription</h2>
    </div>

    <div class="disc_wrapper">

        <div class="prd_disc_wrapper">

        <?php
        print_r ($product->prd_disc);        
        ?>

</div>

    </div>



</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\Documents\github\laravel\my_first_app\B_WEBSITE\b_website\resources\views/product_details.blade.php ENDPATH**/ ?>