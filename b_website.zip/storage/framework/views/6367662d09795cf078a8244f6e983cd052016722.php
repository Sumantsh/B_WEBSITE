
<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>

<div class="banner">
    <img class="img_banner" src="<?php echo e(asset ('img/banner/b5550.webp')); ?>" alt="">
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('products'); ?>

    <div class="prd_wrapper">
        <div class="prd">
            <div class="prd_img">
                <img class="prd_image" src="<?php echo e(asset ('img/asus/Ant-510Air.jpg')); ?>" alt="">
            </div>
            
            <div class="prd_title">
                <h2>Asus MotherBoard</h2>
            </div>

            <div class="prd_price">
                <p >$221</p>
            </div>

            <div class="buybtn">
                <button class="cart_btn">Buy Now</button>
            </div>
        </div>

        <div class="prd">
            <div class="prd_img">
                <img class="prd_image" src="<?php echo e(asset ('img/asus/Gigabyte-led-27fc.jpg')); ?>" alt="">
            </div>
            
            <div class="prd_title">
                <h2>Asus MotherBoard</h2>
            </div>

            <div class="prd_price">
                <p >$221</p>
            </div>

            <div class="buybtn">
                <button class="cart_btn">Buy Now</button>
            </div>
        </div>

        <div class="prd">
            <div class="prd_img">
                <img class="prd_image" src="<?php echo e(asset ('img/asus/Ant-510Air.jpg')); ?>" alt="">
            </div>
            
            <div class="prd_title">
                <h2>Asus MotherBoard</h2>
            </div>

            <div class="prd_price">
                <p >$221</p>
            </div>

            <div class="buybtn">
                <button class="cart_btn">Buy Now</button>
            </div>
        </div>

        <div class="prd">
            <div class="prd_img">
                <img class="prd_image" src="<?php echo e(asset ('img/asus/Ant-510Air.jpg')); ?>" alt="">
            </div>
            
            <div class="prd_title">
                <h2>Asus MotherBoard</h2>
            </div>

            <div class="prd_price">
                <p >$221</p>
            </div>

            <div class="buybtn">
                <button class="cart_btn">Buy Now</button>
            </div>
        </div>

        <div class="prd">
            <div class="prd_img">
                <img class="prd_image" src="<?php echo e(asset ('img/asus/Ant-510Air.jpg')); ?>" alt="">
            </div>
            
            <div class="prd_title">
                <h2>Asus MotherBoard</h2>
            </div>

            <div class="prd_price">
                <p >$221</p>
            </div>

            <div class="buybtn">
                <button class="cart_btn">Buy Now</button>
            </div>
        </div>

        <div class="prd">
            <div class="prd_img">
                <img class="prd_image" src="<?php echo e(asset ('img/asus/Ant-510Air.jpg')); ?>" alt="">
            </div>
            
            <div class="prd_title">
                <h2>Asus MotherBoard</h2>
            </div>

            <div class="prd_price">
                <p >$221</p>
            </div>

            <div class="buybtn">
                <button class="cart_btn">Buy Now</button>
            </div>
        </div> <div class="prd">
            <div class="prd_img">
                <img class="prd_image" src="<?php echo e(asset ('img/asus/Ryzen9-320x320.jpg')); ?>" alt="">
            </div>
            
            <div class="prd_title">
                <h2>Asus MotherBoard</h2>
            </div>

            <div class="prd_price">
                <p >$221</p>
            </div>

            <div class="buybtn">
                <button class="cart_btn">Buy Now</button>
            </div>
        </div>

        <div class="prd">
            <div class="prd_img">
                <img class="prd_image" src="<?php echo e(asset ('img/asus/ryzen.jpeg')); ?>" alt="">
            </div>
            
            <div class="prd_title">
                <h2>Asus MotherBoard</h2>
            </div>

            <div class="prd_price">
                <p >$221</p>
            </div>

            <div class="buybtn">
                <button class="cart_btn">Buy Now</button>
            </div>
        </div>

        <div class="prd">
            <div class="prd_img">
                <img class="prd_image" src="<?php echo e(asset ('img/asus/printer.jpg')); ?>" alt="">
            </div>
            
            <div class="prd_title">
                <h2>Asus MotherBoard</h2>
            </div>

            <div class="prd_price">
                <p >$221</p>
            </div>

            <div class="buybtn">
                <button class="cart_btn">Buy Now</button>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\Desktop\laravel\my_first_app\B_WEBSITE\b_website\resources\views/home.blade.php ENDPATH**/ ?>