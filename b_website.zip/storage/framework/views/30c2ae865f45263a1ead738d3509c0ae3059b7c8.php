
<?php $__env->startSection('title', 'About us'); ?>

<?php $__env->startSection('content'); ?>

<div class="about_wrapper">
    <h2>About us</h2>
</div>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\Documents\github\laravel\my_first_app\B_WEBSITE\b_website\resources\views/about.blade.php ENDPATH**/ ?>